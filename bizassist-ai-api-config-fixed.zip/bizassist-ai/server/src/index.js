import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { randomUUID } from 'node:crypto';
import db from './db.js';
import { connectWhatsApp, disconnectWhatsApp, getLiveState, sendWhatsAppMessage } from './whatsapp.js';
import { generateBusinessReply } from './ai.js';

const app = express();
const PORT = Number(process.env.PORT || 4000);
const JWT_SECRET = process.env.JWT_SECRET || 'unsafe-dev-secret-change-me';
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' }));
app.use(express.json({ limit: '1mb' }));

function auth(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { res.status(401).json({ error: 'Please sign in again.' }); }
}
function safeBusiness(row) {
  return { name: row.name, type: row.type, description: row.description, products: row.products, prices: row.prices, policies: row.policies, language: row.language, personality: row.personality, mode: row.mode, aiEnabled: Boolean(row.ai_enabled) };
}
function getBusiness(userId) {
  let row = db.prepare('SELECT * FROM businesses WHERE user_id=?').get(userId);
  if (!row) {
    db.prepare('INSERT OR IGNORE INTO businesses (user_id) VALUES (?)').run(userId);
    row = db.prepare('SELECT * FROM businesses WHERE user_id=?').get(userId);
  }
  return row;
}
function ownerConnection(userId, id) { return db.prepare('SELECT * FROM connections WHERE id=? AND user_id=?').get(id, userId); }

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'BizAssist AI API' }));
app.post('/api/auth/register', async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (!/^\S+@\S+\.\S+$/.test(email) || password.length < 8) return res.status(400).json({ error: 'Enter a valid email and a password of at least 8 characters.' });
  const id = randomUUID();
  try {
    db.prepare('INSERT INTO users (id,email,password_hash) VALUES (?,?,?)').run(id, email, await bcrypt.hash(password, 12));
    db.prepare('INSERT INTO businesses (user_id) VALUES (?)').run(id);
    const token = jwt.sign({ id, email }, JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user: { id, email } });
  } catch { res.status(409).json({ error: 'That email may already be registered.' }); }
});
app.post('/api/auth/login', async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const row = db.prepare('SELECT * FROM users WHERE email=?').get(email);
  if (!row || !(await bcrypt.compare(String(req.body.password || ''), row.password_hash))) return res.status(401).json({ error: 'Email or password is incorrect.' });
  const token = jwt.sign({ id: row.id, email: row.email }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: row.id, email: row.email } });
});
app.get('/api/me', auth, (req, res) => res.json({ user: { id: req.user.id, email: req.user.email }, business: safeBusiness(getBusiness(req.user.id)) }));
app.put('/api/business', auth, (req, res) => {
  const b = req.body || {};
  const allowed = ['name','type','description','products','prices','policies','language','personality','mode'];
  const current = getBusiness(req.user.id);
  const next = Object.fromEntries(allowed.map(k => [k, String(b[k] ?? current[k] ?? '')]));
  if (!['automatic','manual','hybrid'].includes(next.mode)) return res.status(400).json({ error: 'Invalid assistant mode.' });
  if (!['auto','English','Chichewa'].includes(next.language)) next.language = 'auto';
  if (!['friendly','professional','funny','balanced'].includes(next.personality)) next.personality = 'friendly';
  db.prepare(`UPDATE businesses SET name=@name,type=@type,description=@description,products=@products,prices=@prices,policies=@policies,language=@language,personality=@personality,mode=@mode WHERE user_id=@user_id`)
    .run({ ...next, user_id: req.user.id });
  res.json({ business: safeBusiness(getBusiness(req.user.id)) });
});
app.patch('/api/business/ai', auth, (req, res) => {
  const enabled = Boolean(req.body.enabled);
  db.prepare('UPDATE businesses SET ai_enabled=? WHERE user_id=?').run(enabled ? 1 : 0, req.user.id);
  res.json({ enabled });
});
app.get('/api/connections', auth, (req, res) => {
  const rows = db.prepare('SELECT * FROM connections WHERE user_id=? ORDER BY created_at DESC').all(req.user.id);
  res.json({ connections: rows.map(c => ({ ...c, live: getLiveState(c.id) })) });
});
app.post('/api/connections', auth, (req, res) => {
  const id = randomUUID();
  const label = String(req.body.label || 'WhatsApp account').slice(0, 80);
  db.prepare('INSERT INTO connections (id,user_id,label,status) VALUES (?,?,?,?)').run(id, req.user.id, label, 'disconnected');
  res.json({ connection: db.prepare('SELECT * FROM connections WHERE id=?').get(id) });
});
app.post('/api/connections/:id/connect', auth, async (req, res) => {
  const connection = ownerConnection(req.user.id, req.params.id);
  if (!connection) return res.status(404).json({ error: 'WhatsApp connection not found.' });
  try { await connectWhatsApp(connection, { phoneNumber: req.body.phoneNumber }); res.json({ live: getLiveState(connection.id) }); }
  catch (e) { res.status(400).json({ error: e.message || 'Could not start WhatsApp linking.' }); }
});
app.get('/api/connections/:id/state', auth, (req, res) => {
  if (!ownerConnection(req.user.id, req.params.id)) return res.status(404).json({ error: 'Connection not found.' });
  res.json({ live: getLiveState(req.params.id) });
});
app.delete('/api/connections/:id', auth, async (req, res) => {
  const connection = ownerConnection(req.user.id, req.params.id);
  if (!connection) return res.status(404).json({ error: 'Connection not found.' });
  await disconnectWhatsApp(connection.id);
  db.prepare('DELETE FROM connections WHERE id=? AND user_id=?').run(connection.id, req.user.id);
  res.json({ ok: true });
});
app.get('/api/messages', auth, (req, res) => {
  const connectionId = String(req.query.connectionId || '');
  if (!ownerConnection(req.user.id, connectionId)) return res.status(404).json({ error: 'Choose a valid WhatsApp connection.' });
  const rows = db.prepare(`SELECT m.*, c.label FROM messages m JOIN connections c ON c.id=m.connection_id WHERE m.user_id=? AND m.connection_id=? ORDER BY m.created_at DESC LIMIT 300`).all(req.user.id, connectionId).reverse();
  res.json({ messages: rows });
});
app.post('/api/messages/:id/send', auth, async (req, res) => {
  const msg = db.prepare('SELECT * FROM messages WHERE id=? AND user_id=?').get(req.params.id, req.user.id);
  if (!msg || msg.direction !== 'outgoing' || !msg.suggestion) return res.status(404).json({ error: 'Suggested reply not found.' });
  const connection = ownerConnection(req.user.id, msg.connection_id);
  if (!connection) return res.status(404).json({ error: 'Connection not found.' });
  try {
    await sendWhatsAppMessage(msg.connection_id, msg.wa_jid, msg.suggestion);
    db.prepare('UPDATE messages SET body=?,status=? WHERE id=?').run(msg.suggestion, 'sent', msg.id);
    res.json({ ok: true });
  } catch (e) { res.status(400).json({ error: e.message }); }
});
app.post('/api/preview-reply', auth, async (req, res) => {
  const incoming = String(req.body.message || '').trim();
  if (!incoming) return res.status(400).json({ error: 'Enter a message to test.' });
  try {
    const reply = await generateBusinessReply({ business: getBusiness(req.user.id), incoming, history: [] });
    res.json({ reply });
  } catch (e) { res.status(500).json({ error: e.message || 'Could not generate a reply.' }); }
});

app.listen(PORT, () => console.log(`BizAssist API running on http://localhost:${PORT}`));
