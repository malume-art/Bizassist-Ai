import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID } from 'node:crypto';
import makeWASocket, { DisconnectReason, useMultiFileAuthState } from '@whiskeysockets/baileys';
import pino from 'pino';
import QRCode from 'qrcode';
import db from './db.js';
import { generateBusinessReply, needsHumanReview } from './ai.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const sessionsRoot = path.resolve(here, '../data/sessions');
fs.mkdirSync(sessionsRoot, { recursive: true });
const live = new Map();
const log = pino({ level: 'silent' });

function businessFor(userId) {
  const row = db.prepare('SELECT * FROM businesses WHERE user_id = ?').get(userId);
  return row || { name: '', type: 'Other', description: '', products: '', prices: '', policies: '', language: 'auto', personality: 'friendly', mode: 'manual', ai_enabled: 1 };
}
function updateStatus(id, status, phone = undefined) {
  if (phone !== undefined) db.prepare('UPDATE connections SET status=?, phone=? WHERE id=?').run(status, phone, id);
  else db.prepare('UPDATE connections SET status=? WHERE id=?').run(status, id);
}
function sendState(id, state) {
  const current = live.get(id) || {};
  Object.assign(current, state);
  live.set(id, current);
}

export function getLiveState(id) {
  const s = live.get(id);
  if (!s) return { status: 'disconnected' };
  return { status: s.status || 'connecting', qrDataUrl: s.qrDataUrl || null, pairingCode: s.pairingCode || null, phone: s.phone || null };
}

export async function connectWhatsApp(connection, { phoneNumber } = {}) {
  const id = connection.id;
  if (live.get(id)?.sock) {
    try { live.get(id).sock.end(undefined); } catch {}
  }
  const authDir = path.join(sessionsRoot, id);
  fs.mkdirSync(authDir, { recursive: true });
  const { state, saveCreds } = await useMultiFileAuthState(authDir);
  sendState(id, { status: 'connecting', qrDataUrl: null, pairingCode: null, phone: null });
  updateStatus(id, 'connecting');
  const sock = makeWASocket({ auth: state, logger: log, printQRInTerminal: false, browser: ['BizAssist AI', 'Chrome', '1.0.0'], markOnlineOnConnect: false, syncFullHistory: false });
  sendState(id, { sock });
  sock.ev.on('creds.update', saveCreds);
  sock.ev.on('connection.update', async ({ connection: connState, lastDisconnect, qr }) => {
    if (qr) {
      try { const qrDataUrl = await QRCode.toDataURL(qr); sendState(id, { qrDataUrl, status: 'qr' }); updateStatus(id, 'qr'); } catch {}
    }
    if (connState === 'open') {
      const phone = sock.user?.id?.split(':')[0]?.split('@')[0] || '';
      sendState(id, { status: 'connected', qrDataUrl: null, pairingCode: null, phone });
      updateStatus(id, 'connected', phone);
    }
    if (connState === 'close') {
      const code = lastDisconnect?.error?.output?.statusCode;
      const status = code === DisconnectReason.loggedOut ? 'logged_out' : 'disconnected';
      sendState(id, { status, qrDataUrl: null, pairingCode: null }); updateStatus(id, status);
      if (code !== DisconnectReason.loggedOut) setTimeout(() => {
        const row = db.prepare('SELECT * FROM connections WHERE id=?').get(id);
        if (row && status === 'disconnected') connectWhatsApp(row).catch(() => {});
      }, 3000);
    }
  });
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const msg of messages) {
      if (!msg.message || msg.key.fromMe || !msg.key.remoteJid || msg.key.remoteJid === 'status@broadcast' || msg.key.remoteJid.endsWith('@g.us')) continue;
      const body = extractText(msg.message);
      if (!body) continue;
      const userId = connection.user_id;
      const messageId = randomUUID();
      db.prepare('INSERT INTO messages (id,user_id,connection_id,wa_jid,direction,body,status) VALUES (?,?,?,?,?,?,?)')
        .run(messageId, userId, id, msg.key.remoteJid, 'incoming', body, 'received');
      const business = businessFor(userId);
      if (!business.ai_enabled) continue;
      try {
        const history = db.prepare('SELECT direction,body FROM messages WHERE user_id=? AND connection_id=? AND wa_jid=? ORDER BY created_at DESC LIMIT 8')
          .all(userId, id, msg.key.remoteJid).reverse();
        const reply = await generateBusinessReply({ business, incoming: body, history: history.slice(0, -1) });
        const mode = business.mode || 'manual';
        const humanReview = needsHumanReview(body);
        const shouldSend = mode === 'automatic' || (mode === 'hybrid' && !humanReview);
        const outId = randomUUID();
        db.prepare('INSERT INTO messages (id,user_id,connection_id,wa_jid,direction,body,suggestion,status) VALUES (?,?,?,?,?,?,?,?)')
          .run(outId, userId, id, msg.key.remoteJid, 'outgoing', shouldSend ? reply : '', reply, shouldSend ? 'pending_send' : 'suggested');
        if (shouldSend) {
          await sock.sendMessage(msg.key.remoteJid, { text: reply });
          db.prepare('UPDATE messages SET status=? WHERE id=?').run('sent', outId);
        }
      } catch (err) {
        console.error('AI reply failed:', err.message);
      }
    }
  });
  if (phoneNumber && !state.creds.registered) {
    const clean = phoneNumber.replace(/\D/g, '');
    if (clean.length < 8 || clean.length > 15) throw new Error('Enter a valid phone number with country code, digits only.');
    // Baileys pairing codes should be requested after the socket has initialized.
    setTimeout(async () => {
      try {
        const code = await sock.requestPairingCode(clean);
        sendState(id, { pairingCode: code, status: 'pairing_code' });
        updateStatus(id, 'pairing_code', clean);
      } catch (e) { sendState(id, { pairingError: e.message }); }
    }, 1800);
  }
  return getLiveState(id);
}

function extractText(message) {
  return message.conversation || message.extendedTextMessage?.text || message.imageMessage?.caption || message.videoMessage?.caption || message.documentMessage?.caption || '';
}

export async function disconnectWhatsApp(connectionId) {
  const state = live.get(connectionId);
  if (state?.sock) {
    try { await state.sock.logout(); } catch { try { state.sock.end(undefined); } catch {} }
  }
  live.delete(connectionId);
  updateStatus(connectionId, 'disconnected');
  return { status: 'disconnected' };
}

export async function sendWhatsAppMessage(connectionId, jid, text) {
  const state = live.get(connectionId);
  if (!state?.sock || state.status !== 'connected') throw new Error('WhatsApp account is not connected.');
  await state.sock.sendMessage(jid, { text });
}
