import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.resolve(here, '../data');
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, 'bizassist.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS businesses (
 user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 name TEXT NOT NULL DEFAULT '', type TEXT NOT NULL DEFAULT 'Other', description TEXT NOT NULL DEFAULT '',
 products TEXT NOT NULL DEFAULT '', prices TEXT NOT NULL DEFAULT '', policies TEXT NOT NULL DEFAULT '',
 language TEXT NOT NULL DEFAULT 'auto', personality TEXT NOT NULL DEFAULT 'friendly', mode TEXT NOT NULL DEFAULT 'manual',
 ai_enabled INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS connections (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 label TEXT NOT NULL DEFAULT 'WhatsApp account', phone TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'disconnected',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS messages (
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 connection_id TEXT NOT NULL REFERENCES connections(id) ON DELETE CASCADE,
 wa_jid TEXT NOT NULL, direction TEXT NOT NULL, body TEXT NOT NULL,
 suggestion TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'received', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_messages_owner_chat ON messages(user_id, connection_id, wa_jid, created_at);
`);
export default db;
